instance1: 25 random item sizes between 0.1 and 10 and 15 periodic unavailabilities with random lengths between 0.1 and 10
instance2: 25 item sizes of 1 and 15 random unavailabilities with random lengths between 0.1 and 10
instance3: 25 random item sizes between 1 and 8 and periodic unavailability with random lengths between 0.1 and 10
instance4: 25 random item sizes between 1 and 8 and 15 periodic unavailabilities with length 1
instance5: lognormally randomly distributed input both 25 items and unavailabilities
instance6: small random instance which can be checked by hand
instance7: small random instance which can be checked by hand